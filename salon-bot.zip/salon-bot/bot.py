"""Демо Telegram-бот записи для салона красоты + мини-приложение (Web App).

Работает без внешних библиотек (только стандартная библиотека Python 3.9+).

Переменные окружения:
  BOT_TOKEN   токен от @BotFather (обязательно)
  WEBAPP_URL  https-адрес мини-приложения (папка webapp/ на хостинге)
  ADMIN_ID    ваш Telegram ID: сюда приходят уведомления о новых записях
"""
import html
import json
import os
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path

TOKEN = os.environ.get("BOT_TOKEN", "")
WEBAPP_URL = os.environ.get("WEBAPP_URL", "")
ADMIN_ID = int(os.environ.get("ADMIN_ID", "0") or 0)
DB_PATH = Path(os.environ.get("DB_PATH", Path(__file__).with_name("bookings.json")))

SERVICES = {
    "cut": ("Стрижка", 1500),
    "color": ("Окрашивание", 4500),
    "manicure": ("Маникюр", 2000),
    "brows": ("Брови", 1200),
}
SLOTS = [f"{h:02d}:00" for h in range(10, 20)]

SALON = {
    "name": "Salon Demo",
    "address": "ул. Примерная, 1",
    "phone": "+7 900 000-00-00",
    "hours": "ежедневно 10:00–20:00",
}


# ---------- Telegram API ----------
def api(method, **params):
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{TOKEN}/{method}",
        data=json.dumps(params).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.load(r)["result"]


def send(chat_id, text, **kw):
    return api("sendMessage", chat_id=chat_id, text=text, parse_mode="HTML", **kw)


# ---------- «База данных» (json-файл) ----------
def load_db():
    if DB_PATH.exists():
        return json.loads(DB_PATH.read_text(encoding="utf-8"))
    return []


def save_db(items):
    DB_PATH.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")


def when(b):
    return datetime.strptime(f"{b['date']} {b['time']}", "%Y-%m-%d %H:%M")


def upcoming(items):
    return [b for b in items if when(b) > datetime.now()]


# ---------- Клавиатуры ----------
def webapp_link():
    if not WEBAPP_URL:
        return None
    busy = ",".join(f"{b['date']}T{b['time']}" for b in upcoming(load_db()))
    sep = "&" if "?" in WEBAPP_URL else "?"
    return f"{WEBAPP_URL}{sep}busy={busy}" if busy else WEBAPP_URL


def main_keyboard():
    rows = []
    link = webapp_link()
    if link:
        rows.append([{"text": "📅 Записаться", "web_app": {"url": link}}])
    rows.append([{"text": "📋 Мои записи"}, {"text": "📍 Контакты"}])
    return {"keyboard": rows, "resize_keyboard": True}


# ---------- Обработчики ----------
def on_start(chat_id, user):
    name = html.escape(user.get("first_name", "друг"))
    send(
        chat_id,
        f"Привет, {name}! 👋\nЭто бот записи в <b>{SALON['name']}</b>.\n"
        "Нажмите «📅 Записаться», выберите услугу, дату и время.",
        reply_markup=main_keyboard(),
    )


def on_contacts(chat_id):
    send(
        chat_id,
        f"📍 <b>{SALON['name']}</b>\n{SALON['address']}\n"
        f"📞 {SALON['phone']}\n🕙 {SALON['hours']}",
    )


def on_my(chat_id, user_id):
    mine = sorted(
        (b for b in upcoming(load_db()) if b["user_id"] == user_id), key=when
    )
    if not mine:
        send(chat_id, "У вас пока нет предстоящих записей.")
        return
    for b in mine:
        title, price = SERVICES[b["service"]]
        send(
            chat_id,
            f"✅ <b>{title}</b> — {price} ₽\n🗓 {when(b):%d.%m.%Y} в {b['time']}",
            reply_markup={
                "inline_keyboard": [
                    [{"text": "Отменить запись", "callback_data": f"cancel:{b['id']}"}]
                ]
            },
        )


def on_booking(msg):
    chat_id = msg["chat"]["id"]
    user = msg["from"]
    try:
        data = json.loads(msg["web_app_data"]["data"])
        service, date, slot = data["service"], data["date"], data["time"]
        if service not in SERVICES or slot not in SLOTS:
            raise ValueError("bad value")
        start = datetime.strptime(f"{date} {slot}", "%Y-%m-%d %H:%M")
    except (ValueError, KeyError, TypeError):
        send(chat_id, "Не удалось разобрать заявку. Попробуйте ещё раз.",
             reply_markup=main_keyboard())
        return

    items = load_db()
    if start <= datetime.now():
        send(chat_id, "Это время уже прошло. Выберите другое.",
             reply_markup=main_keyboard())
        return
    if any(b["date"] == date and b["time"] == slot for b in upcoming(items)):
        send(chat_id, "😕 Это время только что заняли. Выберите другое.",
             reply_markup=main_keyboard())
        return

    booking = {
        "id": str(int(time.time() * 1000)),
        "user_id": user["id"],
        "name": user.get("first_name", ""),
        "username": user.get("username", ""),
        "service": service,
        "date": date,
        "time": slot,
    }
    items.append(booking)
    save_db(items)

    title, price = SERVICES[service]
    send(
        chat_id,
        f"🎉 Вы записаны!\n\n<b>{title}</b> — {price} ₽\n"
        f"🗓 {start:%d.%m.%Y} в {slot}\n📍 {SALON['address']}\n\n"
        "Отменить запись можно в разделе «📋 Мои записи».",
        reply_markup=main_keyboard(),
    )
    if ADMIN_ID:
        who = html.escape(booking["name"])
        if booking["username"]:
            who += f" (@{html.escape(booking['username'])})"
        send(ADMIN_ID, f"🔔 Новая запись\n{who}\n{title}, {start:%d.%m.%Y} {slot}")


def on_callback(cb):
    data = cb.get("data", "")
    msg = cb["message"]
    if data.startswith("cancel:"):
        bid = data.split(":", 1)[1]
        items = load_db()
        keep = [b for b in items if not (b["id"] == bid and b["user_id"] == cb["from"]["id"])]
        if len(keep) != len(items):
            save_db(keep)
            api("editMessageText", chat_id=msg["chat"]["id"],
                message_id=msg["message_id"], text="❌ Запись отменена.")
            api("answerCallbackQuery", callback_query_id=cb["id"], text="Запись отменена")
            return
    api("answerCallbackQuery", callback_query_id=cb["id"], text="Запись не найдена")


def handle_update(upd):
    if "callback_query" in upd:
        return on_callback(upd["callback_query"])
    msg = upd.get("message")
    if not msg:
        return
    if "web_app_data" in msg:
        return on_booking(msg)
    text = (msg.get("text") or "").strip()
    chat_id = msg["chat"]["id"]
    if text.startswith("/start") or text.startswith("/help"):
        on_start(chat_id, msg["from"])
    elif text == "📋 Мои записи" or text == "/my":
        on_my(chat_id, msg["from"]["id"])
    elif text == "📍 Контакты":
        on_contacts(chat_id)
    else:
        send(chat_id, "Нажмите «📅 Записаться» или отправьте /start.",
             reply_markup=main_keyboard())


def main():
    if not TOKEN:
        sys.exit("Укажите BOT_TOKEN (токен от @BotFather).")
    if not WEBAPP_URL:
        print("⚠ WEBAPP_URL не задан: кнопка мини-приложения не появится.")
    print("Бот запущен:", api("getMe")["username"])
    offset = 0
    while True:
        try:
            for upd in api("getUpdates", offset=offset, timeout=50):
                offset = upd["update_id"] + 1
                try:
                    handle_update(upd)
                except Exception as e:  # один сбой не должен ронять бота
                    print("Ошибка обработчика:", repr(e))
        except (urllib.error.URLError, TimeoutError) as e:
            print("Сеть:", repr(e))
            time.sleep(3)


if __name__ == "__main__":
    main()
